﻿Public Class Form1
    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.Text = "Karyawan" Then
            TextBox4.Text = "4000000"
        ElseIf ComboBox1.Text = "Leader" Then
            TextBox4.Text = "5000000"
        ElseIf ComboBox1.Text = "Manager" Then
            TextBox4.Text = "6000000"
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        TextBox6.Text = Val(TextBox4.Text) + Val(TextBox5.Text)
    End Sub
End Class
